#
# Copyright (c) 2012-2024 Snowflake Computing Inc. All rights reserved.
#
