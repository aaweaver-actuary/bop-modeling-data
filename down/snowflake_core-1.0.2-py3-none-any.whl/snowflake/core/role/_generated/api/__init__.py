from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.role._generated.api.role_api import RoleApi

__all__ = [
    "RoleApi",
]
